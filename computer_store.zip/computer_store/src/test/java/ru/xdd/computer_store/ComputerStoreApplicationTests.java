package ru.xdd.computer_store;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComputerStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
